-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: rlrmt
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `project_funding`
--

DROP TABLE IF EXISTS `project_funding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_funding` (
  `id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `type` enum('carbon_issue','carbon_sale','donation') NOT NULL,
  `quantity` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `donor_name` varchar(100) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verification_status` enum('pending','verified','rejected','expired') DEFAULT 'pending',
  `credit_standard` varchar(50) DEFAULT NULL COMMENT 'VCS, Gold Standard, CDM, etc.',
  `vintage_year` year DEFAULT NULL COMMENT 'Year credits were generated',
  `verification_body` varchar(100) DEFAULT NULL COMMENT 'Third-party verifier',
  `verification_document` varchar(255) DEFAULT NULL COMMENT 'Path to verification document',
  `verified_at` timestamp NULL DEFAULT NULL,
  `buyer_info` json DEFAULT NULL COMMENT 'Buyer contact and details',
  `platform` varchar(50) DEFAULT 'direct' COMMENT 'Marketplace platform used',
  `price_per_credit` decimal(10,2) DEFAULT NULL COMMENT 'Price per credit in USD',
  `transaction_status` enum('pending','completed','failed','refunded') DEFAULT 'completed',
  `donor_email` varchar(255) DEFAULT NULL,
  `campaign_id` int DEFAULT NULL,
  `is_recurring` tinyint(1) DEFAULT '0',
  `donor_type` enum('individual','corporate','foundation','government') DEFAULT 'individual',
  `donation_status` enum('pending','received','refunded') DEFAULT 'received',
  `receipt_number` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `idx_project_funding_verification` (`verification_status`),
  KEY `idx_project_funding_campaign` (`campaign_id`),
  KEY `idx_project_funding_type_status` (`type`,`transaction_status`),
  KEY `idx_project_funding_donor_email` (`donor_email`),
  CONSTRAINT `project_funding_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_funding`
--

LOCK TABLES `project_funding` WRITE;
/*!40000 ALTER TABLE `project_funding` DISABLE KEYS */;
INSERT INTO `project_funding` VALUES (1,3,'carbon_issue',1,0.00,NULL,'f','2025-06-18 16:54:18','pending',NULL,NULL,NULL,NULL,NULL,NULL,'direct',NULL,'completed',NULL,NULL,0,'individual','received',NULL),(2,3,'carbon_sale',2,100.00,NULL,NULL,'2025-06-18 16:54:26','pending',NULL,NULL,NULL,NULL,NULL,NULL,'direct',NULL,'completed',NULL,NULL,0,'individual','received',NULL),(3,2,'carbon_issue',1,0.00,NULL,NULL,'2025-06-18 17:11:20','verified','VCS',2025,'VCS','','2025-06-18 15:18:10',NULL,'direct',NULL,'completed',NULL,NULL,0,'individual','received',NULL),(4,2,'donation',NULL,100.00,'Anonymous',NULL,'2025-06-18 17:12:48','pending',NULL,NULL,NULL,NULL,NULL,NULL,'direct',NULL,'completed','turachretien@gmail.com',NULL,0,'corporate','received',NULL),(5,2,'carbon_sale',1,4.00,NULL,NULL,'2025-06-18 17:18:20','pending',NULL,NULL,NULL,NULL,NULL,NULL,'direct',4.00,'completed',NULL,NULL,0,'individual','received',NULL),(6,2,'carbon_issue',10,0.00,NULL,NULL,'2025-06-30 14:23:56','pending','VCS',2025,NULL,NULL,NULL,NULL,'direct',NULL,'completed',NULL,NULL,0,'individual','received',NULL),(7,2,'carbon_sale',1,100.00,NULL,NULL,'2025-06-30 14:24:05','pending',NULL,NULL,NULL,NULL,NULL,NULL,'direct',100.00,'completed',NULL,NULL,0,'individual','received',NULL);
/*!40000 ALTER TABLE `project_funding` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-30 16:08:04
