-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: rlrmt
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tree_species`
--

DROP TABLE IF EXISTS `tree_species`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tree_species` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `native` tinyint(1) DEFAULT '0',
  `carbon_rate` float DEFAULT '0',
  `soil_type` varchar(100) DEFAULT NULL,
  `notes` text,
  `image_path` varchar(255) DEFAULT NULL,
  `growth_conditions` text,
  `common_uses` text,
  `planting_season` varchar(100) DEFAULT NULL,
  `soil_improvement` text,
  `environmental_impact` text,
  `rwandan_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree_species`
--

LOCK TABLES `tree_species` WRITE;
/*!40000 ALTER TABLE `tree_species` DISABLE KEYS */;
INSERT INTO `tree_species` VALUES (12,'Podocarpus milanjianus',1,15,'Montane, well-drained','A fast-growing species known for its drought tolerance and timber value.','https://www.zimbabweflora.co.zw/speciesdata/images/23/230750-6.jpg','High elevation, temperate climate, moist soil','Timber, shade, ornamental','Spring','Nitrogen-fixing, soil erosion control','Improves biodiversity, high carbon sequestration','Umufu'),(13,'Mitragyna rubrostipulata',1,12,'Wet, fertile','Native tree in Rwanda with medicinal uses and timber potential.','https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Markhamia_lutea_1zz.jpg/640px-Markhamia_lutea_1zz.jpg','Moist areas, fertile soil','Timber, firewood, medicinal uses','Rainy season','Improves soil structure, enhances local ecosystem','Moderate carbon sequestration','Umusave'),(14,'Nuxia floribunda',1,18,'Wet, moist soils','A fast-growing species found in moist forests of Rwanda, useful in reforestation.','https://trees-sa.co.za/wp-content/uploads/formidable/2/semi-mature-nuxias-in-flower-2.jpg','High rainfall, moist soils','Timber, fuelwood, medicinal purposes','All year round','Soil erosion control, provides habitat','Improves soil fertility and biodiversity','Umubugabuga'),(15,'Dracaena afromontana',1,9,'Highland, fertile','Native ornamental tree in Rwanda, commonly used for shade and aesthetics.','https://inaturalist-open-data.s3.amazonaws.com/photos/80071905/original.jpeg','High altitude, cool temperatures','Ornamental, shade tree, erosion control','Spring to Summer','Soil retention, ornamental purposes','Provides habitat for pollinators','Umuhumuro'),(16,'Croton megalocarpus',1,22,'Sandy, well-drained','A nitrogen-fixing species that grows well in degraded lands, used for timber and soil conservation.','https://live.staticflickr.com/65535/53707348150_29d2e9a38d_b.jpg','Tropical, well-drained soils','Timber, biofuels, medicinal use','Rainy season','Nitrogen-fixing, soil stabilizer','Improves soil fertility, helps restore degraded lands','Umusave'),(17,'Eucalyptus',0,10,'Sandy, well-drained','Non-native species used extensively for timber, firewood, and as a windbreak.','https://www.saje.com/cdn/shop/articles/605581246761.jpg?v=1687291850&width=748','Hot, dry climates','Timber, firewood, windbreaks, medicinal oils','Spring to Early Summer','Improves soil drainage, used for erosion control','Moderate carbon sequestration, drought resistant','Inturusu'),(18,'Cypress',0,8,'Loamy, well-drained','Non-native tree species widely planted for timber and as windbreaks.','https://www.greenwoodnursery.com/sites/default/files/product-imgs/murray%20cypress%20foliage%20gn.jpg','Cool, temperate climates','Timber, ornamental, windbreaks','Spring','Soil improvement, windbreaks','Moderate carbon sequestration','Inturusu'),(19,'Bamboo',1,30,'Well-drained, fertile','Fast-growing grass species that is used for soil conservation and construction.','https://media.houseandgarden.co.uk/photos/65f177973f793999d5fd6559/master/w_1600%2Cc_limit/chuttersnap-BofgeVFG-_w-unsplash.jpg','Tropical and subtropical climates','Construction material, soil stabilization, crafts','Rainy season','Soil erosion control, provides biomass','High carbon sequestration, habitat for wildlife','Imigano');
/*!40000 ALTER TABLE `tree_species` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-30 16:08:04
